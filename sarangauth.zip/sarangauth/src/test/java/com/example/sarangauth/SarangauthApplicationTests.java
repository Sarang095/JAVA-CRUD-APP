package com.example.sarangauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SarangauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
